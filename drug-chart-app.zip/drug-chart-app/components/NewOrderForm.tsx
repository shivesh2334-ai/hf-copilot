"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabase";
import { Plus, X } from "lucide-react";

export default function NewOrderForm({
  patientId,
  onCreated,
}: {
  patientId: string;
  onCreated: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    drug_and_dose: "",
    frequency: "",
    route: "",
    start_date: new Date().toISOString().slice(0, 10),
    doctor_name: "",
    doctor_sign: "",
    remarks: "",
  });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.drug_and_dose.trim()) return;
    setSaving(true);
    const { error } = await supabase.from("drug_orders").insert({
      patient_id: patientId,
      ...form,
    });
    setSaving(false);
    if (!error) {
      setForm({
        drug_and_dose: "",
        frequency: "",
        route: "",
        start_date: new Date().toISOString().slice(0, 10),
        doctor_name: "",
        doctor_sign: "",
        remarks: "",
      });
      setOpen(false);
      onCreated();
    } else {
      alert("Could not add order: " + error.message);
    }
  }

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="w-full ruled-card rounded-sm p-4 flex items-center justify-center gap-2 text-sm font-medium text-clinical-teal hover:bg-clinical-teal/5 transition-colors border-dashed"
      >
        <Plus className="w-4 h-4" /> Add drug &amp; dose order
      </button>
    );
  }

  return (
    <form onSubmit={submit} className="ruled-card rounded-sm p-5 space-y-4">
      <div className="flex items-center justify-between">
        <span className="text-xs font-mono uppercase text-ledger-rule">New order</span>
        <button type="button" onClick={() => setOpen(false)} className="text-ledger-rule hover:text-clinical-red">
          <X className="w-4 h-4" />
        </button>
      </div>

      <div>
        <label className="text-xs font-mono uppercase text-ledger-rule">Drug &amp; dose</label>
        <input
          required
          value={form.drug_and_dose}
          onChange={(e) => setForm({ ...form, drug_and_dose: e.target.value })}
          className="field-underline w-full py-1.5 bg-transparent text-sm"
          placeholder="e.g. Tab. Aspirin 75 mg OD"
        />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div>
          <label className="text-xs font-mono uppercase text-ledger-rule">Frequency</label>
          <input
            value={form.frequency}
            onChange={(e) => setForm({ ...form, frequency: e.target.value })}
            className="field-underline w-full py-1.5 bg-transparent text-sm"
            placeholder="OD / BD / TID"
          />
        </div>
        <div>
          <label className="text-xs font-mono uppercase text-ledger-rule">Route</label>
          <input
            value={form.route}
            onChange={(e) => setForm({ ...form, route: e.target.value })}
            className="field-underline w-full py-1.5 bg-transparent text-sm"
            placeholder="PO / IV / IM"
          />
        </div>
        <div>
          <label className="text-xs font-mono uppercase text-ledger-rule">Start date</label>
          <input
            type="date"
            value={form.start_date}
            onChange={(e) => setForm({ ...form, start_date: e.target.value })}
            className="field-underline w-full py-1.5 bg-transparent text-sm"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="text-xs font-mono uppercase text-ledger-rule">Doctor&apos;s name</label>
          <input
            value={form.doctor_name}
            onChange={(e) => setForm({ ...form, doctor_name: e.target.value })}
            className="field-underline w-full py-1.5 bg-transparent text-sm"
          />
        </div>
        <div>
          <label className="text-xs font-mono uppercase text-ledger-rule">Doctor&apos;s sign</label>
          <input
            value={form.doctor_sign}
            onChange={(e) => setForm({ ...form, doctor_sign: e.target.value })}
            className="field-underline w-full py-1.5 bg-transparent text-sm"
          />
        </div>
      </div>

      <div>
        <label className="text-xs font-mono uppercase text-ledger-rule">Remarks</label>
        <textarea
          value={form.remarks}
          onChange={(e) => setForm({ ...form, remarks: e.target.value })}
          className="field-underline w-full py-1.5 bg-transparent text-sm resize-none"
          rows={2}
        />
      </div>

      <div className="flex justify-end">
        <button
          disabled={saving}
          className="bg-clinical-teal hover:bg-clinical-tealDark text-ledger-paper px-5 py-2 rounded-sm text-sm font-medium disabled:opacity-50"
        >
          {saving ? "Saving…" : "Add order"}
        </button>
      </div>
    </form>
  );
}
