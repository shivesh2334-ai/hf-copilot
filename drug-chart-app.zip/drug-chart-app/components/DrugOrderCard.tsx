"use client";

import { useEffect, useState } from "react";
import { supabase, DrugOrder, AdministrationRecord } from "@/lib/supabase";
import { Check, Square, Ban } from "lucide-react";

export default function DrugOrderCard({
  order,
  index,
  onChanged,
}: {
  order: DrugOrder;
  index: number;
  onChanged: () => void;
}) {
  const [records, setRecords] = useState<AdministrationRecord[]>([]);
  const [nurseSign, setNurseSign] = useState("");
  const [saving, setSaving] = useState(false);

  async function loadRecords() {
    const { data } = await supabase
      .from("administration_records")
      .select("*")
      .eq("drug_order_id", order.id)
      .order("admin_date", { ascending: true })
      .order("admin_time", { ascending: true });
    if (data) setRecords(data as AdministrationRecord[]);
  }

  useEffect(() => {
    loadRecords();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [order.id]);

  async function markGiven() {
    if (!nurseSign.trim()) {
      alert("Enter your initials/sign to record this administration.");
      return;
    }
    setSaving(true);
    const now = new Date();
    const admin_date = now.toISOString().slice(0, 10);
    const admin_time = now.toTimeString().slice(0, 5);
    const { error } = await supabase.from("administration_records").insert({
      drug_order_id: order.id,
      admin_date,
      admin_time,
      nurse_sign: nurseSign.trim(),
    });
    setSaving(false);
    if (!error) {
      setNurseSign("");
      loadRecords();
    } else {
      alert("Could not save: " + error.message);
    }
  }

  async function stopOrder() {
    if (!confirm(`Stop order "${order.drug_and_dose}"?`)) return;
    const stop_date = new Date().toISOString().slice(0, 10);
    const { error } = await supabase
      .from("drug_orders")
      .update({ is_stopped: true, stop_date })
      .eq("id", order.id);
    if (!error) onChanged();
  }

  return (
    <div
      className={`ruled-card rounded-sm overflow-hidden ${
        order.is_stopped ? "opacity-60" : ""
      }`}
    >
      <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] divide-y md:divide-y-0 md:divide-x divide-ledger-line">
        {/* Left: order details */}
        <div className="p-5">
          <div className="flex items-start justify-between mb-3">
            <div>
              <span className="text-xs font-mono text-ledger-rule">
                Order {String(index + 1).padStart(2, "0")}
              </span>
              <h3 className="font-serif text-lg text-ledger-ink leading-snug">
                {order.drug_and_dose}
              </h3>
            </div>
            {order.is_stopped ? (
              <span className="text-xs font-mono uppercase text-clinical-red flex items-center gap-1">
                <Ban className="w-3.5 h-3.5" /> Stopped {order.stop_date}
              </span>
            ) : (
              <button
                onClick={stopOrder}
                className="text-xs font-mono uppercase text-ledger-rule hover:text-clinical-red transition-colors"
              >
                Stop order
              </button>
            )}
          </div>

          <dl className="grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-2 text-sm mb-3">
            <div>
              <dt className="text-xs font-mono text-ledger-rule uppercase">Frequency</dt>
              <dd>{order.frequency || "—"}</dd>
            </div>
            <div>
              <dt className="text-xs font-mono text-ledger-rule uppercase">Route</dt>
              <dd>{order.route || "—"}</dd>
            </div>
            <div>
              <dt className="text-xs font-mono text-ledger-rule uppercase">Start</dt>
              <dd>{order.start_date || "—"}</dd>
            </div>
            <div>
              <dt className="text-xs font-mono text-ledger-rule uppercase">Stop</dt>
              <dd>{order.stop_date || "—"}</dd>
            </div>
          </dl>

          <div className="text-sm mb-3">
            <span className="text-xs font-mono text-ledger-rule uppercase">
              Doctor&apos;s name, sign, date &amp; time
            </span>
            <p>{order.doctor_name || "—"} {order.doctor_sign ? `· ${order.doctor_sign}` : ""} · {new Date(order.order_date_time).toLocaleString()}</p>
          </div>

          {order.remarks && (
            <div className="text-sm">
              <span className="text-xs font-mono text-ledger-rule uppercase">Remarks</span>
              <p className="text-ledger-ink/90">{order.remarks}</p>
            </div>
          )}
        </div>

        {/* Right: administration log, mirrors the Time/Date/Sign columns on the paper chart */}
        <div className="p-5 md:w-72 bg-ledger-paper/60">
          <span className="text-xs font-mono text-ledger-rule uppercase block mb-2">
            Administration record
          </span>
          <div className="max-h-40 overflow-y-auto mb-3">
            <table className="w-full text-xs chart-grid border-collapse">
              <thead>
                <tr className="text-left">
                  <th className="py-1 px-2 font-mono font-medium">Date</th>
                  <th className="py-1 px-2 font-mono font-medium">Time</th>
                  <th className="py-1 px-2 font-mono font-medium">Sign (V)</th>
                </tr>
              </thead>
              <tbody>
                {records.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="py-2 px-2 text-ledger-rule text-center">
                      No doses given yet
                    </td>
                  </tr>
                ) : (
                  records.map((r) => (
                    <tr key={r.id}>
                      <td className="py-1 px-2">{r.admin_date}</td>
                      <td className="py-1 px-2">{r.admin_time}</td>
                      <td className="py-1 px-2 flex items-center gap-1">
                        <Check className="w-3 h-3 text-clinical-teal" /> {r.nurse_sign}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {!order.is_stopped && (
            <div className="flex items-center gap-2">
              <input
                value={nurseSign}
                onChange={(e) => setNurseSign(e.target.value)}
                placeholder="Your sign/initials"
                className="field-underline flex-1 py-1 text-xs bg-transparent"
              />
              <button
                onClick={markGiven}
                disabled={saving}
                className="flex items-center gap-1 bg-clinical-teal hover:bg-clinical-tealDark text-ledger-paper px-2.5 py-1.5 rounded-sm text-xs font-medium disabled:opacity-50"
              >
                <Square className="w-3 h-3" /> Mark given
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
