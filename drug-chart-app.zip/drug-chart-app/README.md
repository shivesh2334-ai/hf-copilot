# Drug &amp; Dose Chart

A digital version of the inpatient "Drug & Dose" medication administration
chart (form YH-MT/NUR-IPD/46) — patient admission, drug orders (drug & dose,
frequency, route, start/stop, doctor's sign), and a per-dose administration
log (date, time, nurse sign) replacing the paper grid.

Stack: Next.js 14 (App Router) · TypeScript · Tailwind CSS · Supabase.

## 1. Set up Supabase

1. Create a project at [supabase.com](https://supabase.com).
2. Open the SQL editor and run `supabase/schema.sql` from this repo.
3. Copy your Project URL and `anon` public key from Project Settings → API.

## 2. Run locally

```bash
npm install
cp .env.local.example .env.local
# paste your Supabase URL and anon key into .env.local
npm run dev
```

Open http://localhost:3000.

## 3. Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit: drug chart app"
git branch -M main
git remote add origin https://github.com/shivesh2334-ai/drug-chart-app.git
git push -u origin main
```

(Create the empty repo first at github.com/new, or use `gh repo create`.)

## 4. Deploy to Vercel

1. Go to [vercel.com/new](https://vercel.com/new) and import the GitHub repo.
2. Add environment variables `NEXT_PUBLIC_SUPABASE_URL` and
   `NEXT_PUBLIC_SUPABASE_ANON_KEY` in Project Settings → Environment Variables.
3. Deploy. `vercel.json` pins the deployment to the Mumbai (`bom1`) region.

Or from the CLI:

```bash
npm i -g vercel
vercel --prod
```

## Notes / next steps

- Row Level Security is currently open (any anon key can read/write) — fine
  for an internal single-ward tool, but add Supabase Auth + role-based
  policies before wider rollout (e.g. restrict administration entries to
  logged-in nursing staff).
- "Sign" fields are typed initials, not cryptographic signatures — matches
  the paper form's intent but isn't legally equivalent to a wet signature.
- The print view (`Print chart` button) gives a clean printout of the current
  chart state per patient.
