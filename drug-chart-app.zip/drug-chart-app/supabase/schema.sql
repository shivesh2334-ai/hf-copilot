-- Drug Chart schema
-- Run this in the Supabase SQL editor for your project.

create extension if not exists "uuid-ossp";

create table if not exists patients (
  id uuid primary key default uuid_generate_v4(),
  mrn text not null,
  name text not null,
  age int,
  sex text,
  ward text,
  bed text,
  admission_date date default current_date,
  created_at timestamptz default now()
);

create table if not exists drug_orders (
  id uuid primary key default uuid_generate_v4(),
  patient_id uuid references patients(id) on delete cascade,
  drug_and_dose text not null,
  frequency text,
  route text,
  start_date date,
  stop_date date,
  doctor_name text,
  doctor_sign text,
  order_date_time timestamptz default now(),
  remarks text,
  is_stopped boolean default false,
  created_at timestamptz default now()
);

create table if not exists administration_records (
  id uuid primary key default uuid_generate_v4(),
  drug_order_id uuid references drug_orders(id) on delete cascade,
  admin_date date not null,
  admin_time time not null,
  nurse_sign text not null,
  created_at timestamptz default now()
);

create index if not exists idx_drug_orders_patient on drug_orders(patient_id);
create index if not exists idx_admin_records_order on administration_records(drug_order_id);

-- Enable row level security. Since this is a single-clinic internal tool,
-- policies below allow full access to anon key. Tighten before wider deployment
-- (e.g. restrict by authenticated staff role) if the app moves beyond internal use.
alter table patients enable row level security;
alter table drug_orders enable row level security;
alter table administration_records enable row level security;

create policy "allow all patients" on patients for all using (true) with check (true);
create policy "allow all drug_orders" on drug_orders for all using (true) with check (true);
create policy "allow all administration_records" on administration_records for all using (true) with check (true);
