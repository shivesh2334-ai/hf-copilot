import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL as string;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Patient = {
  id: string;
  mrn: string;
  name: string;
  age: number | null;
  sex: string | null;
  ward: string | null;
  bed: string | null;
  admission_date: string;
  created_at: string;
};

export type DrugOrder = {
  id: string;
  patient_id: string;
  drug_and_dose: string;
  frequency: string | null;
  route: string | null;
  start_date: string | null;
  stop_date: string | null;
  doctor_name: string | null;
  doctor_sign: string | null;
  order_date_time: string;
  remarks: string | null;
  is_stopped: boolean;
  created_at: string;
};

export type AdministrationRecord = {
  id: string;
  drug_order_id: string;
  admin_date: string;
  admin_time: string;
  nurse_sign: string;
  created_at: string;
};
