"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { supabase, Patient, DrugOrder } from "@/lib/supabase";
import DrugOrderCard from "@/components/DrugOrderCard";
import NewOrderForm from "@/components/NewOrderForm";
import { ArrowLeft, Printer } from "lucide-react";

export default function PatientChartPage() {
  const params = useParams();
  const patientId = params.id as string;

  const [patient, setPatient] = useState<Patient | null>(null);
  const [orders, setOrders] = useState<DrugOrder[]>([]);
  const [loading, setLoading] = useState(true);

  async function loadAll() {
    setLoading(true);
    const [{ data: p }, { data: o }] = await Promise.all([
      supabase.from("patients").select("*").eq("id", patientId).single(),
      supabase
        .from("drug_orders")
        .select("*")
        .eq("patient_id", patientId)
        .order("created_at", { ascending: true }),
    ]);
    if (p) setPatient(p as Patient);
    if (o) setOrders(o as DrugOrder[]);
    setLoading(false);
  }

  useEffect(() => {
    if (patientId) loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [patientId]);

  if (loading) {
    return (
      <main className="max-w-5xl mx-auto px-6 py-12">
        <p className="text-sm text-ledger-rule font-mono">Loading chart…</p>
      </main>
    );
  }

  if (!patient) {
    return (
      <main className="max-w-5xl mx-auto px-6 py-12">
        <p className="text-sm text-clinical-red">Patient not found.</p>
        <Link href="/" className="text-clinical-teal text-sm underline">
          Back to ward list
        </Link>
      </main>
    );
  }

  return (
    <main className="max-w-5xl mx-auto px-6 py-12 print:px-0">
      <div className="flex items-center justify-between mb-6 print:hidden">
        <Link href="/" className="flex items-center gap-1.5 text-sm text-ledger-rule hover:text-clinical-teal">
          <ArrowLeft className="w-4 h-4" /> Ward list
        </Link>
        <button
          onClick={() => window.print()}
          className="flex items-center gap-1.5 text-sm text-ledger-rule hover:text-clinical-teal"
        >
          <Printer className="w-4 h-4" /> Print chart
        </button>
      </div>

      <header className="ruled-card rounded-sm p-6 mb-8">
        <div className="flex items-baseline justify-between flex-wrap gap-y-2">
          <h1 className="font-serif text-2xl font-semibold text-ledger-ink">{patient.name}</h1>
          <span className="text-xs font-mono text-ledger-rule">MRN {patient.mrn}</span>
        </div>
        <p className="text-sm text-ledger-rule mt-1 font-mono">
          {patient.age ?? "—"}{patient.sex ? `/${patient.sex}` : ""} · {patient.ward || "Ward —"}
          {patient.bed ? ` · Bed ${patient.bed}` : ""} · Admitted {patient.admission_date}
        </p>
      </header>

      <div className="space-y-4">
        {orders.length === 0 && (
          <p className="text-sm text-ledger-rule text-center py-6">
            No drug orders charted yet.
          </p>
        )}
        {orders.map((order, i) => (
          <DrugOrderCard key={order.id} order={order} index={i} onChanged={loadAll} />
        ))}

        <div className="print:hidden">
          <NewOrderForm patientId={patientId} onCreated={loadAll} />
        </div>
      </div>
    </main>
  );
}
