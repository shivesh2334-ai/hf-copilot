"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { supabase, Patient } from "@/lib/supabase";
import { Plus, Stethoscope, ArrowRight } from "lucide-react";

export default function HomePage() {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    mrn: "",
    name: "",
    age: "",
    sex: "M",
    ward: "",
    bed: "",
  });

  async function loadPatients() {
    setLoading(true);
    const { data, error } = await supabase
      .from("patients")
      .select("*")
      .order("created_at", { ascending: false });
    if (!error && data) setPatients(data as Patient[]);
    setLoading(false);
  }

  useEffect(() => {
    loadPatients();
  }, []);

  async function admitPatient(e: React.FormEvent) {
    e.preventDefault();
    if (!form.mrn || !form.name) return;
    setSaving(true);
    const { error } = await supabase.from("patients").insert({
      mrn: form.mrn,
      name: form.name,
      age: form.age ? parseInt(form.age) : null,
      sex: form.sex,
      ward: form.ward,
      bed: form.bed,
    });
    setSaving(false);
    if (!error) {
      setForm({ mrn: "", name: "", age: "", sex: "M", ward: "", bed: "" });
      setShowForm(false);
      loadPatients();
    } else {
      alert("Could not admit patient: " + error.message);
    }
  }

  return (
    <main className="max-w-5xl mx-auto px-6 py-12">
      <header className="flex items-start justify-between mb-10 border-b border-ledger-line pb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-sm bg-clinical-teal flex items-center justify-center">
            <Stethoscope className="w-5 h-5 text-ledger-paper" strokeWidth={1.75} />
          </div>
          <div>
            <h1 className="font-serif text-2xl font-semibold tracking-tight text-ledger-ink">
              Drug &amp; Dose Chart
            </h1>
            <p className="text-sm text-ledger-rule font-mono">
              Inpatient medication administration record
            </p>
          </div>
        </div>
        <button
          onClick={() => setShowForm((s) => !s)}
          className="flex items-center gap-2 bg-clinical-teal hover:bg-clinical-tealDark text-ledger-paper px-4 py-2 rounded-sm text-sm font-medium transition-colors"
        >
          <Plus className="w-4 h-4" />
          Admit patient
        </button>
      </header>

      {showForm && (
        <form
          onSubmit={admitPatient}
          className="ruled-card rounded-sm p-6 mb-10 grid grid-cols-2 md:grid-cols-3 gap-5"
        >
          <div>
            <label className="text-xs font-mono uppercase text-ledger-rule">MRN</label>
            <input
              required
              value={form.mrn}
              onChange={(e) => setForm({ ...form, mrn: e.target.value })}
              className="field-underline w-full py-1.5 bg-transparent text-sm"
              placeholder="e.g. YH-2026-0417"
            />
          </div>
          <div>
            <label className="text-xs font-mono uppercase text-ledger-rule">Patient name</label>
            <input
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="field-underline w-full py-1.5 bg-transparent text-sm"
            />
          </div>
          <div>
            <label className="text-xs font-mono uppercase text-ledger-rule">Age</label>
            <input
              value={form.age}
              onChange={(e) => setForm({ ...form, age: e.target.value })}
              className="field-underline w-full py-1.5 bg-transparent text-sm"
              inputMode="numeric"
            />
          </div>
          <div>
            <label className="text-xs font-mono uppercase text-ledger-rule">Sex</label>
            <select
              value={form.sex}
              onChange={(e) => setForm({ ...form, sex: e.target.value })}
              className="field-underline w-full py-1.5 bg-transparent text-sm"
            >
              <option value="M">M</option>
              <option value="F">F</option>
              <option value="Other">Other</option>
            </select>
          </div>
          <div>
            <label className="text-xs font-mono uppercase text-ledger-rule">Ward</label>
            <input
              value={form.ward}
              onChange={(e) => setForm({ ...form, ward: e.target.value })}
              className="field-underline w-full py-1.5 bg-transparent text-sm"
            />
          </div>
          <div>
            <label className="text-xs font-mono uppercase text-ledger-rule">Bed</label>
            <input
              value={form.bed}
              onChange={(e) => setForm({ ...form, bed: e.target.value })}
              className="field-underline w-full py-1.5 bg-transparent text-sm"
            />
          </div>
          <div className="col-span-full flex justify-end">
            <button
              disabled={saving}
              className="bg-clinical-teal hover:bg-clinical-tealDark text-ledger-paper px-5 py-2 rounded-sm text-sm font-medium disabled:opacity-50"
            >
              {saving ? "Admitting…" : "Admit"}
            </button>
          </div>
        </form>
      )}

      <section>
        {loading ? (
          <p className="text-sm text-ledger-rule font-mono">Loading patients…</p>
        ) : patients.length === 0 ? (
          <div className="ruled-card rounded-sm p-10 text-center">
            <p className="text-ledger-rule text-sm">
              No patients on the ward yet. Admit a patient to start a drug chart.
            </p>
          </div>
        ) : (
          <ul className="space-y-3">
            {patients.map((p) => (
              <li key={p.id}>
                <Link
                  href={`/patients/${p.id}`}
                  className="ruled-card rounded-sm p-5 flex items-center justify-between hover:border-clinical-teal transition-colors group"
                >
                  <div>
                    <p className="font-serif text-lg text-ledger-ink">{p.name}</p>
                    <p className="text-xs font-mono text-ledger-rule mt-1">
                      MRN {p.mrn} · {p.age ?? "—"}{p.sex ? `/${p.sex}` : ""} · {p.ward || "Ward —"}{p.bed ? ` · Bed ${p.bed}` : ""}
                    </p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-ledger-rule group-hover:text-clinical-teal group-hover:translate-x-0.5 transition-all" />
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>
    </main>
  );
}
