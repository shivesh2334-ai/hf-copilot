import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Drug Chart | Inpatient Medication Record",
  description: "Digital drug & dose administration chart for inpatient wards.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="font-sans min-h-screen">{children}</body>
    </html>
  );
}
