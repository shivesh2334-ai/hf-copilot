import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ledger: {
          paper: "#FAF9F6",
          line: "#C9CCD3",
          ink: "#1E2430",
          rule: "#8A94A6",
        },
        clinical: {
          teal: "#0F5C5C",
          tealDark: "#0A3F3F",
          amber: "#B8722C",
          red: "#A6382E",
          blue: "#2F5C8A",
        },
      },
      fontFamily: {
        mono: ["'IBM Plex Mono'", "ui-monospace", "SFMono-Regular", "monospace"],
        serif: ["'Source Serif 4'", "Georgia", "serif"],
        sans: ["'IBM Plex Sans'", "ui-sans-serif", "system-ui", "sans-serif"],
      },
      boxShadow: {
        chart: "0 1px 0 rgba(30,36,48,0.06), 0 8px 24px -12px rgba(30,36,48,0.18)",
      },
    },
  },
  plugins: [],
};
export default config;
